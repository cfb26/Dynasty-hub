CFB26 Site Starter (Offline Seasons Hub)
=======================================

What you get
- index.html: main hub page (clickable seasons, search)
- season.html: season page renderer
- js/app.js: table renderer + tabs (no frameworks)
- js/seasons-index.js: list of seasons to show on the hub
- data/season-2031.js: sample season data file

How to add a season
1) Copy: data/season-2031.js
2) Rename to: data/season-YYYY.js (example: data/season-2032.js)
3) Update the "year" field, meta, schedule, and stat tables inside that file.
4) Add an entry for that year in js/seasons-index.js

Open on iPhone/iPad (offline)
- Put the folder in iCloud Drive (Files app).
- Tap index.html -> open in Safari.
- Optional: Safari Share -> Add to Home Screen.

Important note about data loading
- This site does NOT use fetch() so it works from iCloud / Files (file://) without a local web server.
- Each season is a plain JS file that calls window.CFB26_SEASON_LOADED(data).

Next upgrade (when you're ready)
- I can wire an "Import JSON" tool in-browser, so you can paste/export from Excel once and not hand-edit the JS.