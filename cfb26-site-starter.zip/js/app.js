/* CFB26 Site Starter - app.js
   - No frameworks. Offline-friendly (works from Files/iCloud).
   - Data model is plain JS objects, defined in /data/season-YYYY.js files.
*/
(function(){
  function $(sel, root=document){ return root.querySelector(sel); }
  function $all(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

  function esc(s){
    return String(s ?? "").replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }
  function fmt(v){
    if(v === null || v === undefined || v === "") return "";
    if(typeof v === "number") return v.toLocaleString();
    return String(v);
  }
  function fmtPct(v){
    if(v === null || v === undefined || v === "") return "";
    const n = Number(v);
    if(Number.isNaN(n)) return String(v);
    return (n*100).toFixed(1) + "%";
  }
  function fmtDec(v, digits=1){
    if(v === null || v === undefined || v === "") return "";
    const n = Number(v);
    if(Number.isNaN(n)) return String(v);
    return n.toFixed(digits);
  }

  function buildTable(columns, rows){
    const thead = `<thead><tr>${columns.map(c => `<th>${esc(c.label)}</th>`).join("")}</tr></thead>`;
    const tbody = `<tbody>${rows.map(r => {
      return `<tr>${columns.map(c => {
        const raw = (typeof c.value === "function") ? c.value(r) : r[c.key];
        const val = c.format === "pct" ? fmtPct(raw)
                 : c.format === "dec1" ? fmtDec(raw,1)
                 : c.format === "dec2" ? fmtDec(raw,2)
                 : fmt(raw);
        return `<td>${esc(val)}</td>`;
      }).join("")}</tr>`;
    }).join("")}</tbody>`;
    return `<div class="tablewrap"><table>${thead}${tbody}</table></div>`;
  }

  function setActiveTab(groupId, tabId){
    const group = document.getElementById(groupId);
    if(!group) return;
    $all("[data-tab]", group).forEach(t => t.classList.remove("active"));
    const tab = group.querySelector(`[data-tab="${tabId}"]`);
    if(tab) tab.classList.add("active");

    $all("[data-panel]", group).forEach(p => p.style.display = "none");
    const panel = group.querySelector(`[data-panel="${tabId}"]`);
    if(panel) panel.style.display = "block";
  }

  function renderSeason(data){
    // Header
    $("#teamName").textContent = data.team?.name ?? "Team";
    $("#seasonYear").textContent = data.year ?? "";
    $("#seasonSubtitle").textContent = data.meta?.subtitle ?? "";

    const rec = data.meta?.record ?? "";
    const conf = data.meta?.conference ?? "";
    const coach = data.meta?.coach ?? "";
    const bowl = data.meta?.bowl ?? "";
    const rank = data.meta?.rank ?? "";
    $("#kpiRecord").textContent = rec;
    $("#kpiConference").textContent = conf;
    $("#kpiCoach").textContent = coach;
    $("#kpiBowl").textContent = bowl;
    $("#kpiRank").textContent = rank;

    // Overview text / notes
    $("#seasonNotes").innerHTML = (data.meta?.notes && data.meta.notes.trim())
      ? `<p class="muted">${esc(data.meta.notes)}</p>`
      : `<p class="muted">Add a quick season capsule here (style: sports-reference summary).</p>`;

    // Schedule & Results
    const schedCols = [
      {label:"#", key:"game"},
      {label:"Date", key:"date"},
      {label:"Opponent", key:"opponent"},
      {label:"Site", key:"site"},
      {label:"Result", key:"result"},
      {label:"Score", key:"score"},
      {label:"Record", key:"record"},
      {label:"Notes", key:"notes"},
    ];
    $("#scheduleTable").innerHTML = buildTable(schedCols, data.schedule ?? []);

    // Game log (team totals)
    const glCols = [
      {label:"#", key:"game"},
      {label:"Opponent", key:"opponent"},
      {label:"Pts For", key:"pf"},
      {label:"Pts Ag", key:"pa"},
      {label:"Total Yds", key:"totalYds"},
      {label:"Rush Yds", key:"rushYds"},
      {label:"Pass Yds", key:"passYds"},
      {label:"TO", key:"turnovers"},
      {label:"3D%", key:"thirdDownPct", format:"pct"},
      {label:"4D%", key:"fourthDownPct", format:"pct"},
      {label:"Time", key:"top"},
    ];
    $("#gamelogTable").innerHTML = buildTable(glCols, data.gameLog ?? []);

    // Player stats: passing / rushing / receiving (do not cut categories)
    const passCols = [
      {label:"Player", key:"player"},
      {label:"Pos", key:"pos"},
      {label:"GP", key:"gp"},
      {label:"Cmp", key:"cmp"},
      {label:"Att", key:"att"},
      {label:"Pct", key:"pct", format:"pct"},
      {label:"Yds", key:"yds"},
      {label:"Y/A", key:"ya", format:"dec1"},
      {label:"TD", key:"td"},
      {label:"INT", key:"int"},
      {label:"Sacks", key:"sacks"},
      {label:"Rating", key:"rating", format:"dec1"},
      {label:"Rush Att", key:"rushAtt"},
      {label:"Rush Yds", key:"rushYds"},
      {label:"Rush TD", key:"rushTd"},
      {label:"Notes", key:"notes"},
    ];
    $("#passingTable").innerHTML = buildTable(passCols, data.players?.passing ?? []);

    const rushCols = [
      {label:"Player", key:"player"},
      {label:"Pos", key:"pos"},
      {label:"GP", key:"gp"},
      {label:"Att", key:"att"},
      {label:"Yds", key:"yds"},
      {label:"YPC", key:"ypc", format:"dec1"},
      {label:"TD", key:"td"},
      {label:"Long", key:"long"},
      {label:"Fum", key:"fum"},
      {label:"Rec", key:"rec"},
      {label:"Rec Yds", key:"recYds"},
      {label:"Rec TD", key:"recTd"},
      {label:"Notes", key:"notes"},
    ];
    $("#rushingTable").innerHTML = buildTable(rushCols, data.players?.rushing ?? []);

    const recCols = [
      {label:"Player", key:"player"},
      {label:"Pos", key:"pos"},
      {label:"GP", key:"gp"},
      {label:"Rec", key:"rec"},
      {label:"Yds", key:"yds"},
      {label:"Y/R", key:"ypr", format:"dec1"},
      {label:"TD", key:"td"},
      {label:"Long", key:"long"},
      {label:"Targets", key:"tgt"},
      {label:"Drops", key:"drops"},
      {label:"Notes", key:"notes"},
    ];
    $("#receivingTable").innerHTML = buildTable(recCols, data.players?.receiving ?? []);

    // Defense (team & individual)
    const defCols = [
      {label:"Player", key:"player"},
      {label:"Pos", key:"pos"},
      {label:"GP", key:"gp"},
      {label:"Tkl", key:"tkl"},
      {label:"TFL", key:"tfl"},
      {label:"Sacks", key:"sacks", format:"dec1"},
      {label:"INT", key:"int"},
      {label:"PD", key:"pd"},
      {label:"FF", key:"ff"},
      {label:"FR", key:"fr"},
      {label:"TD", key:"td"},
      {label:"Notes", key:"notes"},
    ];
    $("#defenseTable").innerHTML = buildTable(defCols, data.players?.defense ?? []);

    // Special teams (optional sections)
    const kickCols = [
      {label:"Player", key:"player"},
      {label:"FGM", key:"fgm"},
      {label:"FGA", key:"fga"},
      {label:"FG%", key:"fgpct", format:"pct"},
      {label:"XPM", key:"xpm"},
      {label:"XPA", key:"xpa"},
      {label:"Long", key:"long"},
      {label:"Notes", key:"notes"},
    ];
    $("#kickingTable").innerHTML = buildTable(kickCols, data.players?.kicking ?? []);

    const punCols = [
      {label:"Player", key:"player"},
      {label:"Punts", key:"punts"},
      {label:"Yds", key:"yds"},
      {label:"Avg", key:"avg", format:"dec1"},
      {label:"Long", key:"long"},
      {label:"In20", key:"in20"},
      {label:"TB", key:"tb"},
      {label:"Notes", key:"notes"},
    ];
    $("#puntingTable").innerHTML = buildTable(punCols, data.players?.punting ?? []);

    const retCols = [
      {label:"Player", key:"player"},
      {label:"KR", key:"kr"},
      {label:"KR Yds", key:"kryds"},
      {label:"KR Avg", key:"kravg", format:"dec1"},
      {label:"KR TD", key:"krtd"},
      {label:"PR", key:"pr"},
      {label:"PR Yds", key:"pryds"},
      {label:"PR Avg", key:"pravg", format:"dec1"},
      {label:"PR TD", key:"prtd"},
      {label:"Notes", key:"notes"},
    ];
    $("#returnsTable").innerHTML = buildTable(retCols, data.players?.returns ?? []);

    // Awards / honors
    const awards = data.awards ?? [];
    $("#awardsList").innerHTML = awards.length
      ? `<ul>${awards.map(a => `<li>${esc(a)}</li>`).join("")}</ul>`
      : `<div class="notice">No awards listed yet. Add award strings to <code class="inline">data.awards</code>.</div>`;

    // Activate tabs
    setActiveTab("playerTabs", "passing");
    setActiveTab("specialTabs", "kicking");

    // Wire up tab clicks
    $all("#playerTabs [data-tab]").forEach(t => t.addEventListener("click", () => setActiveTab("playerTabs", t.dataset.tab)));
    $all("#specialTabs [data-tab]").forEach(t => t.addEventListener("click", () => setActiveTab("specialTabs", t.dataset.tab)));
  }

  // Public API
  window.CFB26 = {
    renderSeason,
    loadSeasonScript: function(year){
      // Loads /data/season-YYYY.js, which must call window.CFB26_SEASON_LOADED(seasonObj)
      return new Promise((resolve, reject) => {
        const src = `data/season-${year}.js`;
        const s = document.createElement("script");
        s.src = src;
        s.onload = () => resolve(true);
        s.onerror = () => reject(new Error(`Could not load ${src}`));
        document.head.appendChild(s);
      });
    }
  };

  // Hook that data files call
  window.CFB26_SEASON_LOADED = function(seasonObj){
    window.__CFB26_SEASON = seasonObj;
    renderSeason(seasonObj);
  };
})();