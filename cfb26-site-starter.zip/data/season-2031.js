/* data/season-2031.js
   Replace the sample rows with your real 2031 data.
   IMPORTANT: This file must end by calling window.CFB26_SEASON_LOADED(data).
*/
(function(){
  const data = {
    year: 2031,
    team: { name: "Army" },
    meta: {
      subtitle: "Season recap (placeholder)",
      record: "10-3",
      conference: "American",
      coach: "Jeff Monken (sim)",
      bowl: "Armed Forces Bowl (W)",
      rank: "RV",
      notes: "Write a 3–6 sentence capsule here in a sports-reference / 30-for-30 tone once the season data is final."
    },

    // Games numbered; no BYE rows.
    schedule: [
      {game:1, date:"Sep 01", opponent:"Navy", site:"N", result:"W", score:"24-17", record:"1-0", notes:"Rivalry opener"},
      {game:2, date:"Sep 08", opponent:"Air Force", site:"A", result:"L", score:"14-20", record:"1-1", notes:"Red zone stalls"},
      {game:3, date:"Sep 15", opponent:"Tulsa", site:"H", result:"W", score:"31-10", record:"2-1", notes:"+2 TO margin"},
      {game:4, date:"Sep 22", opponent:"Memphis", site:"H", result:"W", score:"27-24", record:"3-1", notes:"Late FG"},
      {game:5, date:"Sep 29", opponent:"SMU", site:"A", result:"W", score:"38-35", record:"4-1", notes:"Explosive runs"},
      {game:6, date:"Oct 06", opponent:"UAB", site:"H", result:"W", score:"21-13", record:"5-1", notes:"Defense closed"},
      {game:7, date:"Oct 13", opponent:"ECU", site:"A", result:"L", score:"17-19", record:"5-2", notes:"Missed XP"},
      {game:8, date:"Oct 20", opponent:"Temple", site:"H", result:"W", score:"42-14", record:"6-2", notes:"300+ rush"},
      {game:9, date:"Oct 27", opponent:"Tulane", site:"A", result:"W", score:"28-21", record:"7-2", notes:"4D stop"},
      {game:10, date:"Nov 03", opponent:"USF", site:"H", result:"W", score:"35-28", record:"8-2", notes:"QB kept 18x"},
      {game:11, date:"Nov 10", opponent:"Cincinnati", site:"A", result:"W", score:"24-23", record:"9-2", notes:"Walk-off"},
      {game:12, date:"Nov 17", opponent:"Houston", site:"H", result:"L", score:"20-27", record:"9-3", notes:"TOs"},
      {game:13, date:"Dec 27", opponent:"Baylor", site:"N", result:"W", score:"30-27", record:"10-3", notes:"Bowl win"}
    ],

    gameLog: [
      {game:1, opponent:"Navy", pf:24, pa:17, totalYds:361, rushYds:248, passYds:113, turnovers:1, thirdDownPct:0.47, fourthDownPct:0.50, top:"33:18"},
      {game:2, opponent:"Air Force", pf:14, pa:20, totalYds:295, rushYds:210, passYds:85, turnovers:2, thirdDownPct:0.36, fourthDownPct:0.00, top:"31:02"},
      {game:3, opponent:"Tulsa", pf:31, pa:10, totalYds:402, rushYds:312, passYds:90, turnovers:0, thirdDownPct:0.55, fourthDownPct:1.00, top:"35:41"}
      // Add remaining games...
    ],

    players: {
      passing: [
        {player:"K. Daniels", pos:"QB", gp:13, cmp:78, att:135, pct:0.578, yds:1320, ya:9.8, td:12, int:5, sacks:14, rating:142.6, rushAtt:168, rushYds:980, rushTd:16, notes:"Primary runner"},
        {player:"J. Miles", pos:"QB", gp:4, cmp:12, att:22, pct:0.545, yds:160, ya:7.3, td:1, int:1, sacks:3, rating:110.2, rushAtt:22, rushYds:110, rushTd:2, notes:"Change-up"}
      ],
      rushing: [
        {player:"K. Daniels", pos:"QB", gp:13, att:168, yds:980, ypc:5.8, td:16, long:42, fum:3, rec:0, recYds:0, recTd:0, notes:"Keep game"},
        {player:"T. Hightower", pos:"FB", gp:13, att:190, yds:1045, ypc:5.5, td:12, long:36, fum:1, rec:6, recYds:54, recTd:0, notes:"Dive/ISO"},
        {player:"M. Carter", pos:"HB", gp:13, att:92, yds:612, ypc:6.7, td:6, long:58, fum:0, rec:10, recYds:140, recTd:2, notes:"Perimeter"}
      ],
      receiving: [
        {player:"A. Webb", pos:"WR", gp:13, rec:24, yds:530, ypr:22.1, td:5, long:67, tgt:36, drops:2, notes:"Play-action"},
        {player:"S. Knox", pos:"TE", gp:13, rec:18, yds:260, ypr:14.4, td:3, long:28, tgt:26, drops:1, notes:"Seam/flat"}
      ],
      defense: [
        {player:"D. Harris", pos:"LB", gp:13, tkl:112, tfl:9, sacks:3.5, int:1, pd:4, ff:2, fr:1, td:0, notes:"MIKE"},
        {player:"R. Alvarez", pos:"DL", gp:13, tkl:58, tfl:14, sacks:8.0, int:0, pd:1, ff:1, fr:0, td:0, notes:"Edge"}
      ],
      kicking: [
        {player:"C. Bishop", fgm:12, fga:16, fgpct:0.750, xpm:32, xpa:33, long:47, notes:"Reliable"},
      ],
      punting: [
        {player:"L. Grant", punts:48, yds:2090, avg:43.5, long:61, in20:18, tb:3, notes:"Field position"},
      ],
      returns: [
        {player:"M. Carter", kr:18, kryds:512, kravg:28.4, krtd:1, pr:11, pryds:138, pravg:12.5, prtd:0, notes:"Primary returner"},
      ]
    },

    awards: [
      "All-Conference 1st Team — T. Hightower (FB)",
      "All-Conference 2nd Team — R. Alvarez (DL)",
      "Bowl MVP — K. Daniels (QB)"
    ]
  };

  window.CFB26_SEASON_LOADED(data);
})();