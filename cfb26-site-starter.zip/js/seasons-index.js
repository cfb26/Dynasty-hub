/* seasons-index.js
   List your available seasons here.
   Each season should have: year, team, record, conference, coach (optional), and a short subtitle.
*/
window.CFB26_SEASONS_INDEX = [
  {
    year: 2031,
    team: "Army",
    record: "10-3",
    conference: "American",
    coach: "Jeff Monken (sim)",
    rank: "RV",
    subtitle: "Option offense at volume; +15.2 rush EPA (sim)",
    notes: "Replace this with your real season capsule once you have full data."
  },
  {
    year: 2030,
    team: "Army",
    record: "8-5",
    conference: "American",
    coach: "Jeff Monken (sim)",
    rank: "",
    subtitle: "Defense improved late; one-score games swung variance",
    notes: ""
  },
  {
    year: 2029,
    team: "Army",
    record: "11-2",
    conference: "American",
    coach: "Jeff Monken (sim)",
    rank: "No. 18",
    subtitle: "Best rushing efficiency of the era; low-turnover profile",
    notes: ""
  }
];